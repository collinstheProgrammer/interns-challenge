package com.example.loginform;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class Login_form extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;



    private EditText emailID, passwordID;
    private Button loginID;
    private Button btnSignup;

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthStateListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);

        mAuth = FirebaseAuth.getInstance();
        emailID = findViewById(R.id.emailID);
        passwordID = findViewById(R.id.passwordID);
        loginID = findViewById(R.id.loginID);
        btnSignup = findViewById(R.id.signUpBtn1);

     mAuthStateListener = new FirebaseAuth.AuthStateListener() {
         @Override
         public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
             FirebaseUser mFirebaseUser = mAuth.getCurrentUser();
             if (mFirebaseUser != null){
                 Toast.makeText(Login_form.this, "You are logged in", Toast.LENGTH_LONG).show();
                 Intent intent  = new Intent(Login_form.this, MainActivity.class);
                 startActivity(intent);
             } else{
                 Toast.makeText(Login_form.this, "Please Log in", Toast.LENGTH_LONG).show();

             }

         }
     };


       loginID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailID.getText().toString();
                String pwd = passwordID.getText().toString();


                //check if the use already has an account

                if(email.isEmpty()){
                    emailID.setError("Please Enter email address");
                    emailID.requestFocus();


                } else if(pwd.isEmpty()){
                    passwordID.setError("please enter your password");
                    passwordID.requestFocus();


                } else if (email.isEmpty()&& pwd.isEmpty()){
                    Toast.makeText(Login_form.this, "fields are empty", Toast.LENGTH_SHORT).show();

                }else if (email.isEmpty()&& pwd.isEmpty()){
                    mAuth.signInWithEmailAndPassword(email, pwd).addOnCompleteListener(Login_form.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                Toast.makeText(Login_form.this, "email and password field cannot be empty", Toast.LENGTH_LONG).show();
                            }
                        }
                    });



                  /*  mAuth.createUserWithEmailAndPassword(email, pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                Toast.makeText(Login_form.this, "Sign up is unsuccessful, please try again", Toast.LENGTH_SHORT).show();

                            } else{
                                startActivity(new Intent(Login_form.this,MainActivity.class));


                            }
                        }
                    }); */



                } else {
                    Toast.makeText(Login_form.this, "Error occurred ", Toast.LENGTH_SHORT).show();
                }



            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intentSignUp = new Intent(Login_form.this, SignUp.class);
               startActivity(intentSignUp);
           }



       });

    }





}
