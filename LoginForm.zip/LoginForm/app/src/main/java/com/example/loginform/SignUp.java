package com.example.loginform;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class SignUp extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private EditText emailID, passwordID;
    private Button  SignUpBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);

        mAuth = FirebaseAuth.getInstance();
        emailID = findViewById(R.id.emailID);
        passwordID = findViewById(R.id.passwordID);
        SignUpBtn = findViewById(R.id.signUpBtn1);

        SignUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailID.getText().toString();
                String pwd = passwordID.getText().toString();


                //check if the use already has an account

                if(email.isEmpty()){
                    emailID.setError("Please Enter email address");
                    emailID.requestFocus();


                } else if(pwd.isEmpty()){
                    passwordID.setError("please enter your password");
                    passwordID.requestFocus();


                } else if (email.isEmpty()&& pwd.isEmpty()){
                    Toast.makeText(SignUp.this, "fields are empty", Toast.LENGTH_SHORT).show();

                }else if (email.isEmpty()&& pwd.isEmpty()){
                    mAuth.createUserWithEmailAndPassword(email, pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()){
                                Toast.makeText(SignUp.this, "Sign up is unsuccessful, please try again", Toast.LENGTH_SHORT).show();

                            } else{
                                startActivity(new Intent(SignUp.this,MainActivity.class));


                            }
                        }
                    });



                } else {
                    Toast.makeText(SignUp.this, "Error occurred ", Toast.LENGTH_SHORT).show();
                }



            }
        });
    }




}
